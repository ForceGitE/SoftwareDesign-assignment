var searchData=
[
  ['quiz',['Quiz',['../class_quiz.html',1,'']]]
];
