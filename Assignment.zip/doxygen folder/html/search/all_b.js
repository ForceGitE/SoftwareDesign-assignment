var searchData=
[
  ['name',['Name',['../classtinyxml2_1_1_x_m_l_attribute.html#a8124fbfd27f57150cc68d8a9207078c3',1,'tinyxml2::XMLAttribute::Name()'],['../classtinyxml2_1_1_x_m_l_element.html#a8bff355472bce2c60d4b50a212bf7f5f',1,'tinyxml2::XMLElement::Name()']]],
  ['newcomment',['NewComment',['../classtinyxml2_1_1_x_m_l_document.html#a386df0befd06aadb5e0cd21381aa955a',1,'tinyxml2::XMLDocument']]],
  ['newdeclaration',['NewDeclaration',['../classtinyxml2_1_1_x_m_l_document.html#ae519030c0262fa2daff8993681990e16',1,'tinyxml2::XMLDocument']]],
  ['newelement',['NewElement',['../classtinyxml2_1_1_x_m_l_document.html#a3c335a700a43d7c363a393142a23f234',1,'tinyxml2::XMLDocument']]],
  ['newtext',['NewText',['../classtinyxml2_1_1_x_m_l_document.html#acece5de77a0819f2341b08c1e1ed9987',1,'tinyxml2::XMLDocument']]],
  ['newunknown',['NewUnknown',['../classtinyxml2_1_1_x_m_l_document.html#a4954f502c5fd7f49de54c3c0c99bb73d',1,'tinyxml2::XMLDocument']]],
  ['next',['Next',['../classtinyxml2_1_1_x_m_l_attribute.html#a7fd852d6185af90361ec1bc9a7681ad6',1,'tinyxml2::XMLAttribute']]],
  ['nextsibling',['NextSibling',['../classtinyxml2_1_1_x_m_l_node.html#abba1df37581d89dccc45acdc55750ba2',1,'tinyxml2::XMLNode::NextSibling()'],['../classtinyxml2_1_1_x_m_l_handle.html#aad2eccc7c7c7b18145877c978c3850b5',1,'tinyxml2::XMLHandle::NextSibling()']]],
  ['nextsiblingelement',['NextSiblingElement',['../classtinyxml2_1_1_x_m_l_node.html#ab66a0818d72cee86e0952ed2da701f8b',1,'tinyxml2::XMLNode::NextSiblingElement()'],['../classtinyxml2_1_1_x_m_l_handle.html#ae41d88ee061f3c49a081630ff753b2c5',1,'tinyxml2::XMLHandle::NextSiblingElement()']]],
  ['nochildren',['NoChildren',['../classtinyxml2_1_1_x_m_l_node.html#a96afe34a9ccd0ed4c0cff32beb42cc6c',1,'tinyxml2::XMLNode']]]
];
