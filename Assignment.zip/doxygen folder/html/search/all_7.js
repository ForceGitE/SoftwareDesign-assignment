var searchData=
[
  ['hasbom',['HasBOM',['../classtinyxml2_1_1_x_m_l_document.html#a530649e9de7e5aa8df9c37f66197fcb6',1,'tinyxml2::XMLDocument']]]
];
