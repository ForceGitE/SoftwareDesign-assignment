var searchData=
[
  ['boolattribute',['BoolAttribute',['../classtinyxml2_1_1_x_m_l_element.html#a1fda1104d4d1fbdbcc896b0efd9b9496',1,'tinyxml2::XMLElement']]],
  ['booltext',['BoolText',['../classtinyxml2_1_1_x_m_l_element.html#a6cf3fcf510bcb9e40d09fab7c52e5f0b',1,'tinyxml2::XMLElement']]],
  ['boolvalue',['BoolValue',['../classtinyxml2_1_1_x_m_l_attribute.html#afb444b7a12527f836aa161b54b2f7ce7',1,'tinyxml2::XMLAttribute']]]
];
