var searchData=
[
  ['getdocument',['GetDocument',['../classtinyxml2_1_1_x_m_l_node.html#add244bca368083fa29698db8dcf147ca',1,'tinyxml2::XMLNode::GetDocument() const '],['../classtinyxml2_1_1_x_m_l_node.html#af343d1ef0b45c0020e62d784d7e67a68',1,'tinyxml2::XMLNode::GetDocument()']]],
  ['geterrorstr1',['GetErrorStr1',['../classtinyxml2_1_1_x_m_l_document.html#a016ccebecee36fe92084b5dfee6cc072',1,'tinyxml2::XMLDocument']]],
  ['geterrorstr2',['GetErrorStr2',['../classtinyxml2_1_1_x_m_l_document.html#a88f6b44bd019033bda28abd31fe257b2',1,'tinyxml2::XMLDocument']]],
  ['gettext',['GetText',['../classtinyxml2_1_1_x_m_l_element.html#a56cc727044dad002b978256754d43a4b',1,'tinyxml2::XMLElement']]],
  ['getuserdata',['GetUserData',['../classtinyxml2_1_1_x_m_l_node.html#aa4442e68dca53c3f339238101ea55e30',1,'tinyxml2::XMLNode']]]
];
